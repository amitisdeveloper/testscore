import { BaseCRUD } from '../../src/crud/base'

export default BaseCRUD.UpdatePage
