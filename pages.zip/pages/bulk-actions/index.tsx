import { CRUD } from '../../src/crud/bulkActions'

export default CRUD.IndexPage
