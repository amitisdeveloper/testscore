declare module '@editorjs/header'
declare module '@editorjs/image'
declare module '@editorjs/paragraph'
declare module '@editorjs/nested-list'
