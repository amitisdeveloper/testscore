import { PopconfirmLocaleType } from '../interfaces'

export const ruRU: PopconfirmLocaleType = {
    cancelTitle: 'Отмена',
    confirmTitle: 'Подтвердить',
}
