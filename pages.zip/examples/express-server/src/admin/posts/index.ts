export { default as posts } from './posts.route';
