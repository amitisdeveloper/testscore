import { BaseCRUD } from '../../src/crud/quickFilters'

export default BaseCRUD.IndexPage
