import React from 'react'
import MainPage from '../src/pages/MainPage'

const Home: React.FC = () => {
    return <MainPage />
}

export default Home
