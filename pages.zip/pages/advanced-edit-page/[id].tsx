import UpdatePage from '../../src/crud/advancedEditPage/EditPage'

export default UpdatePage
