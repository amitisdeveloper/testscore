import { BaseCRUD } from '../../src/crud/base'

export default BaseCRUD.IndexPage
