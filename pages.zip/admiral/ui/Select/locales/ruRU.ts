import { SelectLocale } from '../interfaces'

export const ruRU: SelectLocale = {
    notFound: 'Не найдено',
}
