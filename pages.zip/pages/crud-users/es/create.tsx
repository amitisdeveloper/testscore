import { UsersCRUD } from '../../../src/crud/users/users-es'

export default UsersCRUD.CreatePage
