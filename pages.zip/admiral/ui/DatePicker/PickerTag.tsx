import React from 'react'

export default function PickerTag(props: any) {
    return <span color="blue" {...props} />
}
