import { SelectLocale } from '../interfaces'

export const enUS: SelectLocale = {
    notFound: 'Not found',
}
