import { CRUD } from '@/src/crud/users'

export default CRUD.IndexPage
