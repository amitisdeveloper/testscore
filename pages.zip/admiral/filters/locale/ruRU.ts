import { FiltersLocale } from '../interfaces'

export const ruRU: FiltersLocale = {
    title: 'Фильтры',
    clear: 'Очистить все',
    submit: 'Применить',
}
