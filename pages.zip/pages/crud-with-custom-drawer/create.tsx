import { CRUD } from '../../src/crud/customDrawer'

export default CRUD.CreatePage
