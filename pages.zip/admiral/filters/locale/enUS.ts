import { FiltersLocale } from '../interfaces'

export const enUS: FiltersLocale = {
    title: 'Filters',
    clear: 'Clear all',
    submit: 'Apply',
}
