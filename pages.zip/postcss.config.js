module.exports = {
    plugins: {
        'postcss-color-mod-function': {},
    },
}
