import { CRUD } from '../../src/crud/advancedEditPage'

export default CRUD.IndexPage
