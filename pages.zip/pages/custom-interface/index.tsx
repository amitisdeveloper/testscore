import ThemePage from '../../src/crud/customInterface'

export default ThemePage
