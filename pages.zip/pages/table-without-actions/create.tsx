import { CRUD } from '../../src/crud/tableWithoutActions'

export default CRUD.CreatePage
