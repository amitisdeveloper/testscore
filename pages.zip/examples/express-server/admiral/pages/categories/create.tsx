import { CRUD } from '@/src/crud/categories'

export default CRUD.CreatePage
