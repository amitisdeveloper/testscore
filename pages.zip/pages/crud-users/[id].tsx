import { UsersCRUD } from '../../src/crud/users'

export default UsersCRUD.UpdatePage
