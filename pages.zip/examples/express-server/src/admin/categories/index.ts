export { default as categories } from './categories.route';
