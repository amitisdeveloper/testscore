export { default as auth } from './auth.route';
