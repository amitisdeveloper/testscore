import { PopconfirmLocaleType } from '../interfaces'

export const enUS: PopconfirmLocaleType = {
    cancelTitle: 'Cancel',
    confirmTitle: 'Confirm',
}
