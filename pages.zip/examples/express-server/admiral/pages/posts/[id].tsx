import { CRUD } from '@/src/crud/posts'

export default CRUD.UpdatePage
