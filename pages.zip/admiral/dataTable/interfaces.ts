import { PopconfirmLocaleType } from '../ui/Popconfirm/interfaces'

export type DataTableType = {
    title: string
} & PopconfirmLocaleType
